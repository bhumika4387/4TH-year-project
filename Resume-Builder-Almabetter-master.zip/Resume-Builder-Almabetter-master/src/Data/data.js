import Resume1 from '../Templetes/Resume1'
import Resume2 from '../Templetes/Resume2'
import Resume3 from '../Templetes/Resume3'
import Resume4 from '../Templetes/Resume4'

// Stores All Templates As a json State 
const temp =[
{
thumbnail:'/images/Templete1.png',
data:<Resume1/>},

{
thumbnail:'/images/Templete2.jpg',
data:<Resume2/>},

{
thumbnail:'/images/Templete3.jpg',
data:<Resume3/>},

{
thumbnail:'/images/Templete4.jpg',
data:<Resume4/>}

]

export default temp ;