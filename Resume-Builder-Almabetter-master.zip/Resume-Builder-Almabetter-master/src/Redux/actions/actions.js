// Actions for personal information Data 
export const SET_CONTACT = 'SET_CONTACT'
export const UPDATE_CONTACT =' UPDATE_CONTACT'

// Actions for Education information Data 
export const SET_EDUCATION = 'SET_EDUCATION'
export const UPDATE_EDUCATION = 'UPDATE_EDUCATION'

// Actions for Work Experience information Data 
export const SET_EXPERIENCE= 'SET_EXPERIENCE'
export const UPDATE_EXPERIENCE= 'UPDATE_EXPERIENCE'

// Actions for Keyskills information Data 
export const SET_KEYSKILLS= 'SET_KEYSKILLS'
export const UPDATE_KEYSKILLS= 'UPDATE_KEYSKILLS'

// Actions for Templete selection 
export const SET_TEMPLATE= 'SET_TEMPLATE'
export const UPDATE_TEMPLATE= 'UPDATE_TEMPLATE'

// Actions for Saving resume to "My-resume"
export const SAVE_RESUME= 'SAVE_RESUME'