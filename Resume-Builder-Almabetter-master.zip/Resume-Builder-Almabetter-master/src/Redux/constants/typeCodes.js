 
 const fieldCd = {
     /*Personal Information State */

    FirstName: "FNAM",
    LastName: "LNAM",
    Email: "EMAIL",
    Address: "ADRS",
    Mobile: "MOBL",
    City: "CITY",
    State: "STAT",
    Postal: "PSTL",
    Dob: "DOB",
    Objective: "OBJT",

    /* Education information State*/ 

    Type: "TYPE",
    Degree: "DGRE",
    Startyear: "STYR",
    Endyear: "EDYR",
    University:"UNST",

};

export default fieldCd
 